export const blue1f5 = '#1F5CB8'
export const white = '#FFFFFF'
export const blue307 = '#3073D7'
export const blue004 = '#004EC2'
