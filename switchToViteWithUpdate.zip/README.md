стэк: React, React-Router, Redux-Toolkit, i18n, dnd-kit, antd, tailwind
проверка авторизации пользователя в RequireAuth.tsx
сетка dnd храниться в localstorage отрисовка происходит в функции generateDOM() в файле DropDrag.tsx
