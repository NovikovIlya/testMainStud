import React from 'react';

export const stepBusinessTrip = [
    {id: 1, link: '/services/businessTrip/newBusinessTrip/stepOne'},
    {id: 2, link: '/services/businessTrip/newBusinessTrip/stepTwo'},
    {id: 3, link: '/services/businessTrip/newBusinessTrip/stepThree'},
    {id: 4, link: '/services/businessTrip/newBusinessTrip/stepFour'},
]

