import React from 'react'

const ViewSchedule = () => {
	return <div>ViewSchedule</div>
}

export default ViewSchedule
