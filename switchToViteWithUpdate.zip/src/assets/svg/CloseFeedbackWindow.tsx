import React from 'react';

export const CloseFeedbackWindow = () => {
    return (
        <svg width="27" height="29" viewBox="0 0 27 29" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M7.19922 7.03394L19.9271 21.0402" stroke="#B3B3B3" strokeWidth="1.57667" strokeLinecap="round"/>
            <path d="M7.2002 21.0404L19.9281 7.0341" stroke="#B3B3B3" strokeWidth="1.57667" strokeLinecap="round"/>
        </svg>

    );
};

