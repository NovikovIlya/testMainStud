export const Dashboard = () => {
	return (
		<div>
			<div>Личный кабинет КФУ</div>
		</div>
	)
}
