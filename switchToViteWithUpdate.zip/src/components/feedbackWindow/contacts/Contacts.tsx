import React from 'react';

export const Contacts = () => {
    return (
        <div className={'flex py-4 gap-2 justify-center border-solid border-t-2 border-0 border-[#D9D9D9]'}>
             <span className={'text-[17px]/[19px] font-bold text-[#808080]'}>
                 newlksupport@kpfu.ru
             </span>
        </div>
    );
};

