import React from 'react'

const ViewDocument = () => {
	return <div>ViewDocument</div>
}

export default ViewDocument
