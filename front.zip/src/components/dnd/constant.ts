export const block = {
	lg: [
		{
			w: 1,
			h: 1,
			maxH: 4,
			maxW: 4,
			x: 0,
			y: 0,
			i: 'ElectronicBook',
			moved: true,
			static: false
		},
		{
			w: 1,
			h: 1,
			maxH: 4,
			maxW: 4,
			x: 1,
			y: 0,
			i: 'Session',
			moved: true,
			static: false
		}
	]
}
