import React from 'react'

export const Photo = () => {
	return <div>Photo</div>
}
