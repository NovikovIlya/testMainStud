import React from 'react';

export const LeftBack = () => {
    return (
        <svg width="10" height="15" viewBox="0 0 10 15" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M9.2998 1.20837L1.2998 7.70837C4.424 10.2468 6.17561 11.67 9.2998 14.2084" stroke="#B3B3B3"
                  strokeWidth="1.34" strokeLinecap="round" strokeLinejoin="round"/>
        </svg>

    );
};

