export const validateMessages = {
    required: "Обязательное поле",
    string: {
        max: "Не больше ${max} символов",
    },
    types: {
        email: 'Введите корректную почту',
    },

};
